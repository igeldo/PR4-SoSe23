package com.example.weatherappspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherappspringApplicationTests {

    @Test
    void contextLoads() {
    }

}
