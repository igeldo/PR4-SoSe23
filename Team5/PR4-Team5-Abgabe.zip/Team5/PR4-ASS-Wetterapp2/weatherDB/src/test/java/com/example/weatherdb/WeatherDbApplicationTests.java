package com.example.weatherdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
