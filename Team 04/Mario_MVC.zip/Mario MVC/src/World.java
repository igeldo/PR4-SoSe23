import java.util.ArrayList;
import java.util.List;

public class World {
    private Player player;
    private List<Enemy> enemies;
    private List<Platform> platforms;
    // Weitere Attribute und Methoden
    private int width; // die Breite der Welt
    private int height; // die Höhe der Welt

    public World(int width, int height) {
        this.width = width;
        System.out.print(width);
        this.height = height;
        // Initialisieren Sie den Spieler und die anderen Objekte hier
        player = new Player(200,200,120,240);
        enemies = new ArrayList<>();
        platforms = new ArrayList<>();

        // Fügen Sie Plattformen zur Liste hinzu
        platforms.add(new Platform(0, 550, 10000, 100));
    }

    public void update() {
        // Aktualisieren Sie die Spiellogik
        //player.update();
        player.update(platforms);

        for (Platform platform : platforms) {
            if (player.intersects(platform)) {
                player.handleCollision(platform);
            }
        }

        for (Enemy enemy : enemies) {
            enemy.update();
        }
    }

    // Getter-Methode für den Spieler
    public Player getPlayer() {
        return player;
    }

    public List<Platform> getPlatforms() {
        return platforms;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
    // Weitere Getter- und Setter-Methoden für die anderen Objekte
}
