import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class PlatformView {
    private Platform platform;
    private ImageView imageView;

    public PlatformView(Platform platform) {
        this.platform = platform;
        Image platformImage = new Image("Images/platformPeter.png"); // Ändern Sie den Pfad zu Ihrem Plattformbild
        imageView = new ImageView(platformImage);
        imageView.setFitWidth(platform.getWidth());
        imageView.setFitHeight(platform.getHeight());
        imageView.setX(platform.getX());
        imageView.setY(platform.getY());
    }

    public ImageView getImageView() {
        return imageView;
    }
}