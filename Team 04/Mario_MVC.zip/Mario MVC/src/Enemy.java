public class Enemy {
    // Attribute und Methoden

    public void update() {
        // Aktualisieren Sie die Position des Gegners und führen Sie ihre KI aus (z. B. Bewegung, Angriffe)
    }
}