import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.List;
import java.util.stream.Collectors;

public class WorldView extends Pane {
    private World world;
    private PlayerView playerView;
    private List<PlatformView> platformViews;
    private ImageView backgroundView;
    private ScrollPane scrollPane;

    public WorldView(World world, ScrollPane scrollPane) {
        this.world = world;
        this.scrollPane = scrollPane;
        this.playerView = new PlayerView(world.getPlayer());
        platformViews = world.getPlatforms().stream()
                .map(PlatformView::new)
                .collect(Collectors.toList());

        // Erstellen Sie den Hintergrund
        Image backgroundImage = new Image("Images/background.jpg"); // Ändern Sie den Pfad zu Ihrem Hintergrundbild
        backgroundView = new ImageView(backgroundImage);
        backgroundView.setFitWidth(1000); // Passen Sie die Breite an Ihre Anforderungen an
        backgroundView.setFitHeight(800); // Passen Sie die Höhe an Ihre Anforderungen an

        // Fügen Sie den Hintergrund zur Kinderliste hinzu
        getChildren().add(backgroundView);

        // Fügen Sie die Spielerelemente zur Kinderliste hinzu
        getChildren().add(playerView.getPlayerView());
        platformViews.forEach(pv -> getChildren().add(pv.getImageView()));
    }

    public void draw() {
        playerView.update();
        adjustCamera();
    }

    private void adjustCamera() {
        Player player = world.getPlayer();

        double viewportWidth = scrollPane.getViewportBounds().getWidth();
        double viewportHeight = scrollPane.getViewportBounds().getHeight();

        double playerCenterX = player.getX() + player.getWidth() / 2.0;
        double playerCenterY = player.getY() + player.getHeight() / 2.0;

        double newViewportX = playerCenterX - viewportWidth / 2.0;
        double newViewportY = playerCenterY - viewportHeight / 2.0;

        double maxViewportX = world.getWidth() - viewportWidth;
        double maxViewportY = world.getHeight() - viewportHeight;

        // Adjust the new viewport position to keep the player centered
        if (maxViewportX > 0) {
            newViewportX = Math.max(0, Math.min(newViewportX, maxViewportX));
        } else {
            newViewportX = viewportWidth / 2.0 - playerCenterX;
        }

        if (maxViewportY > 0) {
            newViewportY = Math.max(0, Math.min(newViewportY, maxViewportY));
        } else {
            newViewportY = viewportHeight / 2.0 - playerCenterY;
        }

        // Update the viewport
        scrollPane.setHvalue(newViewportX / maxViewportX);
        scrollPane.setVvalue(newViewportY / maxViewportY);
    }






}

