import javafx.geometry.Rectangle2D;


public class Platform {

    private double x;
    private double y;
    private double width;
    private double height;
    // Attribute und Methoden

    public Platform(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        // Weitere Initialisierungen
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public Rectangle2D getBounds() {
            return new Rectangle2D(x, y, width, height);
        }
}
