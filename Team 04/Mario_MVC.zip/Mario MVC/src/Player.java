import java.util.List;
import javafx.geometry.Rectangle2D;


public class Player {
    private double width;
    private double height;
    private double x;
    private double y;
    private double velocityX;
    private double velocityY;
    private static final double GRAVITY = 0.5; // Passen Sie den Wert nach Bedarf an
    private boolean onGround;
    private int lastDirection = 1;

    // Weitere Attribute und Methoden

    public Player(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        // Weitere Initialisierungen
    }

    public void update(List<Platform> platforms) {
        // Aktualisieren Sie die Position des Spielers basierend auf der Geschwindigkeit
        x += velocityX;
        y += velocityY;

        // Schwerkraft anwenden
        if (!isOnGround(platforms)) {
            velocityY += GRAVITY;
        } else {
            velocityY = 0;
        }

        onGround = isOnGround(platforms);

        // Wenn der Spieler in der Luft ist, wenden Sie die Schwerkraft an
        if (!onGround) {
            velocityY += GRAVITY;
        } else {
            velocityY = 0;
        }
    }


    // Getter-Methoden für die x- und y-Koordinaten
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    // Weitere Getter- und Setter-Methoden für die anderen Attribute

    // Steuerungsmethoden
    public void moveLeft() {
        velocityX = -15; // Passen Sie die Geschwindigkeit nach Bedarf an
        lastDirection = -1;
    }

    public void moveRight() {
        velocityX = 15; // Passen Sie die Geschwindigkeit nach Bedarf an
        lastDirection = 1;
    }


    public void jump(List<Platform> platforms) {
        System.out.println("Attempting to jump"); // Debug-Ausdruck
        if (isOnGround(platforms)) {
            velocityY = -20; // Passen Sie die Sprunghöhe nach Bedarf an
            onGround = false;
        }
    }

    public boolean isOnGround(List<Platform> platforms) {
        double tolerance = 1.0;
        Rectangle2D playerBounds = getBounds();

        // Erstellen Sie eine Unterstützungsfläche unterhalb des Spielers, um zu überprüfen, ob er auf einer Plattform steht
        Rectangle2D supportSurface = new Rectangle2D(playerBounds.getMinX(), playerBounds.getMaxY(),
                playerBounds.getWidth(), tolerance);

        // Überprüfen Sie, ob die Unterstützungsfläche eine Plattform berührt
        for (Platform platform : platforms) {
            Rectangle2D platformBounds = platform.getBounds();

            if (supportSurface.intersects(platformBounds)) {
                y = platformBounds.getMinY() - height; // Korrigieren Sie die y-Position des Spielers, um auf der Plattform zu stehen
                velocityY = 0; // Stoppen Sie die vertikale Geschwindigkeit des Spielers
                onGround = true; // Der Spieler steht auf dem Boden
                return true;
            }
        }

        onGround = false; // Der Spieler steht nicht auf dem Boden
        return false;
    }



    public boolean intersects(Platform platform) {
        Rectangle2D playerBounds = getBounds();
        Rectangle2D platformBounds = platform.getBounds();
        return playerBounds.intersects(platformBounds);
    }

    public void handleCollision(Platform platform) {
        Rectangle2D playerBounds = getBounds();
        Rectangle2D platformBounds = platform.getBounds();

        // Berechnen Sie die Kollisionsrichtung und korrigieren Sie die Position des Spielers entsprechend
        double dx = Math.min(playerBounds.getMaxX() - platformBounds.getMinX(),
                platformBounds.getMaxX() - playerBounds.getMinX());
        double dy = Math.min(playerBounds.getMaxY() - platformBounds.getMinY(),
                platformBounds.getMaxY() - playerBounds.getMinY());

        if (Math.abs(dx) < Math.abs(dy)) {
            if (playerBounds.getMinX() < platformBounds.getMinX()) {
                x -= dx;
            } else {
                x += dx;
            }
        } else {
            if (playerBounds.getMinY() < platformBounds.getMinY()) {
                y -= dy;
                velocityY = 0;
                onGround = true;
            } else {
                y += dy;
                velocityY = 0;
            }
        }
    }

    public Rectangle2D getBounds() {
        return new Rectangle2D(x, y, width, height);
    }

    public int getLastDirection() {
        return lastDirection;
    }


    public void stopMoving() {
        velocityX = 0;
    }
}

