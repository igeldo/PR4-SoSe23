import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyEvent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class GameController extends AnimationTimer {
    private World world;
    private WorldView worldView;
    private Scene scene;


    public GameController(World world, WorldView worldView, Scene scene) {
        this.world = world;
        this.worldView = worldView;
        this.scene = scene;


        // Fügen Sie EventListener für Tastatureingaben hinzu
        addKeyListeners();

        // Starten Sie den AnimationTimer
        this.start();
    }

    @Override
    public void handle(long now) {
        world.update();
        worldView.draw();
    }

    private void addKeyListeners() {
        scene.setOnKeyPressed((KeyEvent event) -> {
            switch (event.getCode()) {
                case UP:
                    world.getPlayer().jump(world.getPlatforms());
                    break;
                case LEFT:
                    world.getPlayer().moveLeft();
                    break;
                case RIGHT:
                    world.getPlayer().moveRight();
                    break;
            }
        });

        scene.setOnKeyReleased((KeyEvent event) -> {
            switch (event.getCode()) {
                case LEFT:
                case RIGHT:
                    world.getPlayer().stopMoving();
                    break;
            }
        });
    }
}
