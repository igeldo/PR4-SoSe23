import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class PlayerView {
    private Player player;
    private ImageView imageView;

    public PlayerView(Player player) {
        this.player = player;
        Image playerImage = new Image("Images/peter.png"); // Ändern Sie den Pfad zu Ihrem Spielerbild
        imageView = new ImageView(playerImage);
        imageView.setFitWidth(player.getWidth());
        imageView.setFitHeight(player.getHeight());
    }

    public void update() {
        imageView.setScaleX(player.getLastDirection());

        // Aktualisieren Sie die Position der ImageView basierend auf der Position des Spielers
        imageView.setX(player.getX());
        imageView.setY(player.getY());
    }

    public ImageView getPlayerView() {
        return imageView;
    }
}
