import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        World world = new World(10000, 1000);

        ScrollPane scrollPane = new ScrollPane();

        WorldView worldView = new WorldView(world, scrollPane);
        scrollPane.setContent(worldView);

        Scene scene = new Scene(scrollPane, 1600, 900);

        // Instanziieren Sie den GameController
        GameController gameController = new GameController(world, worldView, scene);

        primaryStage.setTitle("Super Peter");
        primaryStage.setScene(scene);
        primaryStage.show();


    }

    public static void main(String[] args) {
        launch(args);
    }
}


