import javafx.scene.image.ImageView;

public class EnemyView extends ImageView {
    private Enemy enemy;

    public EnemyView(Enemy enemy) {
        this.enemy = enemy;
        // Laden Sie das Enemy-Bild und fügen Sie es hier hinzu
    }

    // Weitere Methoden zur Aktualisierung der Darstellung
}
