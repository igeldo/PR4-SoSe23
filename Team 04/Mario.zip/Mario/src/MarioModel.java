public class MarioModel {
    private double x;
    private double y;
    private boolean movingLeft;
    private boolean movingRight;

    double gravity = 1; // Gravitationskraft, die auf Mario wirkt
    double jumpStrength = 20.0; // Stärke des Sprungs, ändere sie nach Bedarf
    //boolean isMarioOnGround =

    public MarioModel(int x, int y) {
        this.x = x;
        this.y = y;
        movingLeft = false;
        movingRight = false;
    }

    public void setMovingLeft(boolean movingLeft) {
        this.movingLeft = movingLeft;
    }

    public void setMovingRight(boolean movingRight) {
        this.movingRight = movingRight;
    }

    public boolean isMovingLeft() {
        return movingLeft;
    }

    public boolean isMovingRight() {
        return movingRight;
    }

    public void jump() {
        // Implementieren Sie hier die Sprunglogik
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}


