import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Starter extends Application {

    private Pane root;

    private Scene scene;
    private double sceneWidth = 800;
    private double sceneHeight = 600;


    private boolean leftKeyPressed = false;
    private boolean rightKeyPressed = false;
    private boolean upKeyPressed = false;
    private double marioVerticalSpeed = 0;
    private double marioAcceleration = 0;
    private boolean enemyAlive = true;
    private double enemySpeed = 2.0;






    @Override
    public void start(Stage primaryStage) {
        root = new Pane();

        scene = new Scene(root, sceneWidth, sceneHeight);

        scene.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case LEFT:
                    leftKeyPressed = true;
                    break;
                case RIGHT:
                    rightKeyPressed = true;
                    break;
                case UP:
                    upKeyPressed = true;
                    break;



            }
        });

        scene.setOnKeyReleased(event -> {
            switch (event.getCode()) {
                case LEFT:
                    leftKeyPressed = false;
                    break;
                case RIGHT:
                    rightKeyPressed = false;
                    break;
                case UP:
                    upKeyPressed = false;
                    break;
            }
        });

        // Erstelle den Spielcharakter (Mario)
        Image marioImage = new Image("Mario.png");
        ImageView mario = new ImageView(marioImage);
        mario.setFitWidth(60);
        mario.setFitHeight(80);
        mario.setX(50);
        mario.setY(50);

        Image enemyImage = new Image("enemy.jpg");
        ImageView enemy = new ImageView(enemyImage);
        enemy.setFitWidth(80);
        enemy.setFitHeight(80);
        enemy.setX(400); // X-Position des Gegners
        enemy.setY(500); // Y-Position des Gegners, ändere sie nach Bedarf



        root.getChildren().add(mario);
        root.getChildren().add(enemy);


        // Spiellogik
        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {

                double marioSpeed = 5.0; // Grundgeschwindigkeit
                double maxSpeed = 10.0; // Maximale Geschwindigkeit
                double accelerationRate = 0.1; // Beschleunigungsrate



                /// Berechne die neue X-Position von Mario
                double newX = mario.getX();
                if (leftKeyPressed) {
                    marioAcceleration = Math.max(marioAcceleration - accelerationRate, -maxSpeed + marioSpeed);
                    newX = mario.getX() - (marioSpeed - marioAcceleration);
                    mario.setScaleX(-1); // Spiegelt das Bild horizontal
                } else if (rightKeyPressed) {
                    marioAcceleration = Math.min(marioAcceleration + accelerationRate, maxSpeed - marioSpeed);
                    newX = mario.getX() + (marioSpeed + marioAcceleration);
                    mario.setScaleX(1); // Setzt das Bild auf die ursprüngliche Ausrichtung zurück
                } else {
                    marioAcceleration = 0; // Setzt die Beschleunigung zurück, wenn keine Taste gedrückt wird
                }

                if (enemyAlive) {
                    // Überprüfe die Kollision
                    mario.setX(newX);
                    String collisionSide = checkCollision(mario, enemy);
                    if (collisionSide != null) {
                        if (collisionSide.equals("left")) {
                            mario.setX(enemy.getX() - mario.getFitWidth());
                        } else if (collisionSide.equals("right")) {
                            mario.setX(enemy.getX() + enemy.getFitWidth());
                        } else if (collisionSide.equals("top")) {
                            // Entferne den Gegner, wenn Mario von oben auf ihn draufspringt
                            root.getChildren().remove(enemy);
                            enemyAlive = false;
                        }
                    }
                } else {
                    mario.setX(newX);
                }




                double gravity = 1.0; // Gravitationskraft, die auf Mario wirkt
                double jumpStrength = 20.0; // Stärke des Sprungs, ändere sie nach Bedarf
                double groundY = 500.0;
                boolean isMarioOnGround = mario.getY() >= groundY; // Überprüfe, ob Mario auf dem Boden steht (ändere die Y-Koordinate nach Bedarf)

                if (upKeyPressed && isMarioOnGround) {
                    marioVerticalSpeed = -jumpStrength;
                }

                marioVerticalSpeed += gravity;
                mario.setY(mario.getY() + marioVerticalSpeed);

                if (isMarioOnGround && mario.getY() > groundY) {
                    mario.setY(groundY);
                    marioVerticalSpeed = 0;
                }


                // Aktualisiere die Position von Mario oder anderen Spielobjekten
                // updatePositions();

                // Zeichne die Spielobjekte neu
                // renderObjects();

                // Prüfe Kollisionen
                // checkCollisions();

                // Führe andere Spiellogik aus
                // updateGameLogic();
            }
        };

        AnimationTimer enemyAnimationTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                // Aktualisiere die Position des Gegners
                enemy.setX(enemy.getX() + enemySpeed);

                // Ändere die Richtung des Gegners, wenn er den Bildschirmrand erreicht
                if (enemy.getX() <= 0 || enemy.getX() + enemy.getFitWidth() >= scene.getWidth()) {
                    enemySpeed = -enemySpeed;
                }
            }
        };




        gameLoop.start();
        enemyAnimationTimer.start();

        primaryStage.setTitle("Super Mario JavaFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private String checkCollision(ImageView object1, ImageView object2) {
        if (object1.getBoundsInParent().intersects(object2.getBoundsInParent())) {
            double dx = object1.getX() - object2.getX();
            double dy = object1.getY() - object2.getY();
            double topTolerance = 4.0; // Toleranz für die Kollision von oben

            if (Math.abs(dx) > Math.abs(dy)) {
                return dx > 0 ? "right" : "left";
            } else {
                if (dy > 0 && Math.abs(dx) < object2.getFitWidth() / 2 - topTolerance) {
                    return "bottom";
                } else if (dy < 0 && Math.abs(dx) < object2.getFitWidth() / 2 - topTolerance) {
                    return "top";
                }
            }
        }
        return null;
    }



    public static void main(String[] args) {
        launch(args);
    }
}
