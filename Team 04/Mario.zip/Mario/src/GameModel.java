public class GameModel {
    private MarioModel mario;
    private EnemyModel enemy;

    public GameModel() {
        mario = new MarioModel(50, 500);
        enemy = new EnemyModel(350, 505);
    }

    public MarioModel getMario() {
        return mario;
    }

    public EnemyModel getEnemy() {
        return enemy;
    }
}
