import javafx.scene.layout.Pane;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class GameView {
    private Pane root;
    private Scene scene;
    private GameModel model;
    private ImageView marioView;
    private ImageView enemyView;
    double groundY = 500.0;
    boolean isMarioOnGround = marioView.getY() >= groundY;

    public void update(GameModel model) {
        marioView.setX(model.getMario().getX());
        marioView.setY(model.getMario().getY());
        enemyView.setX(model.getEnemy().getX());
        enemyView.setY(model.getEnemy().getY());
    }



    public void updateMarioDirection(boolean facingLeft) {
        if (facingLeft) {
            marioView.setScaleX(-1);
        } else {
            marioView.setScaleX(1);
        }
    }

    public GameView(GameModel model) {
        this.model = model;
        root = new Pane();
        scene = new Scene(root, 800, 600);
        marioView = new ImageView(new Image("Mario.png", 40, 40, true, true));
        enemyView = new ImageView(new Image("enemy.jpg", 40, 40, true, true));
        root.getChildren().addAll(marioView, enemyView);

        // Setze die Positionen der Bilder entsprechend den Modellen
        marioView.setX(model.getMario().getX());
        marioView.setY(scene.getHeight() - marioView.getImage().getHeight() - 30);
        enemyView.setX(scene.getWidth() / 2 - enemyView.getImage().getWidth() / 2);
        enemyView.setY(scene.getHeight() - enemyView.getImage().getHeight() - 30);
    }

    public Pane getRoot() {
        return root;
    }

    public Scene getScene() {
        return scene;
    }

    public boolean getIsMarioOnGround() {
        return isMarioOnGround;
    }

    // Getter und Setter für visuelle Elemente
}

