import javafx.animation.AnimationTimer;
import javafx.scene.layout.Pane;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.input.KeyEvent;
import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyEvent;

public class GameController {
    private GameModel model;
    private GameView view;
    private AnimationTimer gameLoop;
    boolean isMarioOnGround = view.getIsMarioOnGround();

    public GameController(GameModel model, GameView view) {
        this.model = model;
        this.view = view;

        view.getScene().setOnKeyPressed(this::handleKeyPress);
        view.getScene().setOnKeyReleased(this::handleKeyRelease);

        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                updateModel();
                updateView();
            }
        };
        gameLoop.start();
    }

    private void handleKeyPress(KeyEvent event) {
        switch (event.getCode()) {
            case LEFT:
                model.getMario().setMovingLeft(true);
                view.updateMarioDirection(true);
                break;
            case RIGHT:
                model.getMario().setMovingRight(true);
                view.updateMarioDirection(false);
                break;
            case UP:
                model.getMario().jump();
                break;
        }
    }


    private void handleKeyRelease(KeyEvent event) {
        switch (event.getCode()) {
            case LEFT:
                model.getMario().setMovingLeft(false);
                break;
            case RIGHT:
                model.getMario().setMovingRight(false);
                break;
        }
    }

    private void updateModel() {
        MarioModel mario = model.getMario();

        if (mario.isMovingLeft()) {
            mario.setX(mario.getX() - 5);
        }
        if (mario.isMovingRight()) {
            mario.setX(mario.getX() + 5);
        }

        // Fügen Sie hier weitere Spiellogik-Updates hinzu
    }

    private void updateView() {
        view.update(model);
    }
}
